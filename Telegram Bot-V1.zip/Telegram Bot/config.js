module.exports = {
  TELEGRAM_TOKEN: '8314788198:AAHRmvNz9Kh2nQUE-qYV6gtyKMxGChEW6AA', // Remplace par le token du bot Telegram

  // Lien d'invitation pour le bouton "Channel"
  CHANNEL_INVITE_LINK: 'https://t.me/ton_channel', 

  // Lien d'invitation pour le bouton "Group"
  GROUP_LINK: 'https://t.me/ton_groupe', 

  // Liste des ID Telegram considérés comme propriétaires (Owner)
  // ⚠️ Ces IDs doivent être des entiers (pas des strings)
  owner: [7799545092, 987654321], // Remplace par ton ID Telegram
};
